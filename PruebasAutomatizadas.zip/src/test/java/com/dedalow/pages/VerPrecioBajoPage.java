package com.dedalow.pages;

import java.util.logging.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.By;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.aventstack.extentreports.Status;
import com.dedalow.report.Report;
import com.dedalow.utils.Utils;
import com.dedalow.utils.Constant;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class VerPrecioBajoPage {

        private WebDriver driver;
        private Class reflectiveClass;
        private JavascriptExecutor js;
        private static Logger logger = Utils.logger();

        public VerPrecioBajoPage(Class reflectiveClass) throws Exception {
                this.reflectiveClass = reflectiveClass;
                this.driver = (WebDriver) reflectiveClass.getField("driver").get(reflectiveClass);
                PageFactory.initElements(driver, this);
                js = (JavascriptExecutor) driver;

        }

        public VerPrecioBajoPage pulsarVerPrecio() throws Exception {

                By pulsarVerPrecio = By.xpath(
                                "/html/body/app-root/div/app-menuprincipal/deda-grid[1]/div/deda-grid/div/div[1]/deda-button/button");
                By Titulo2 = By.xpath(
                                "/html/body/app-root/div/app-menuprincipal/deda-grid[1]/div/div[3]/deda-text-box/input");
                By NombreAutor2 = By
                                .xpath("/html/body/app-root/div/app-menuprincipal/deda-grid[1]/div/div[7]/deda-text-box/input");
                By ApellidosAutor2 = By
                                .xpath("/html/body/app-root/div/app-menuprincipal/deda-grid[1]/div/div[11]/deda-text-box/input");

                driver.findElement(Titulo2).clear();
                driver.findElement(Titulo2).sendKeys("Los pilares de la tierra");
                Report.reportLog(reflectiveClass, "Typed " + "Los pilares de la tierra in Titulo2",
                                "INFO",
                                0, Status.PASS, true, "", "", null);

                driver.findElement(NombreAutor2).clear();
                driver.findElement(NombreAutor2).sendKeys("Ken");
                Report.reportLog(reflectiveClass, "Typed " + "Ken in NombreAutor2", "INFO", 0, Status.PASS, true, "",
                                "",
                                null);

                driver.findElement(ApellidosAutor2).clear();
                driver.findElement(ApellidosAutor2).sendKeys("Follet");
                Report.reportLog(reflectiveClass, "Typed " + "Follet in ApellidosAutor2", "INFO", 0, Status.PASS,
                                true,
                                "", "", null);

                new WebDriverWait(driver, Duration.ofSeconds(20))
                                .until(ExpectedConditions.elementToBeClickable(pulsarVerPrecio));
                Report.reportLog(reflectiveClass, "Condition pulsarVerPrecio isClickable finished", "ASYNCHRONOUS", 0);

                driver.findElement(pulsarVerPrecio).click();
                Report.reportLog(reflectiveClass, "Clicked pulsarVerPrecio", "INFO", 0, Status.PASS, true, "", "",
                                null);
                return this;
        }
}