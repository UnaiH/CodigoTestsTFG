package com.dedalow.pages;

import java.util.logging.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.By;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.aventstack.extentreports.Status;
import com.dedalow.report.Report;
import com.dedalow.utils.Utils;
import com.dedalow.utils.Constant;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class EliminarResenaPage {

    private WebDriver driver;
    private Class reflectiveClass;
    private JavascriptExecutor js;
    private static Logger logger = Utils.logger();

    public EliminarResenaPage(Class reflectiveClass) throws Exception {
        this.reflectiveClass = reflectiveClass;
        this.driver = (WebDriver) reflectiveClass.getField("driver").get(reflectiveClass);
        PageFactory.initElements(driver, this);
        js = (JavascriptExecutor) driver;

    }

    public EliminarResenaPage EliminarResena() throws Exception {

        By EliminarResena = By.xpath(
                "/html/body/app-root/div/app-verresenas/deda-grid/div/div[5]/table/tbody/tr/td[3]/deda-button/button");

        new WebDriverWait(driver, Duration.ofSeconds(20))
                .until(ExpectedConditions.elementToBeClickable(EliminarResena));
        Report.reportLog(reflectiveClass, "Condition EliminarResena isClickable finished", "ASYNCHRONOUS", 0);

        driver.findElement(EliminarResena).click();
        Report.reportLog(reflectiveClass, "Clicked EliminarResena", "INFO", 0, Status.PASS, true, "", "", null);
        return this;
    }
}