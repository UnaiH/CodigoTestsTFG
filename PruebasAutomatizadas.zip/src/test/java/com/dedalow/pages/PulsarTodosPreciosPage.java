package com.dedalow.pages;

import java.util.logging.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.By;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.aventstack.extentreports.Status;
import com.dedalow.report.Report;
import com.dedalow.utils.Utils;
import com.dedalow.utils.Constant;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class PulsarTodosPreciosPage {

        private WebDriver driver;
        private Class reflectiveClass;
        private JavascriptExecutor js;
        private static Logger logger = Utils.logger();

        public PulsarTodosPreciosPage(Class reflectiveClass) throws Exception {
                this.reflectiveClass = reflectiveClass;
                this.driver = (WebDriver) reflectiveClass.getField("driver").get(reflectiveClass);
                PageFactory.initElements(driver, this);
                js = (JavascriptExecutor) driver;

        }

        public PulsarTodosPreciosPage pulsarTodosPrecios() throws Exception {

                By pulsarTodosPrecios = By.xpath(
                                "/html/body/app-root/div/app-menuprincipal/deda-grid[1]/div/deda-grid/div/div[2]/deda-button/button");
                By Titulo = By.xpath(
                                "/html/body/app-root/div/app-menuprincipal/deda-grid[1]/div/div[3]/deda-text-box/input");
                By NombreAutor = By
                                .xpath("/html/body/app-root/div/app-menuprincipal/deda-grid[1]/div/div[7]/deda-text-box/input");
                By ApellidosAutor = By
                                .xpath("/html/body/app-root/div/app-menuprincipal/deda-grid[1]/div/div[11]/deda-text-box/input");

                WebDriverWait wait = new WebDriverWait(driver, 10);
                WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(
                                "/html/body/app-root/div/app-menuprincipal/deda-grid[1]/div/deda-grid/div/div[2]/deda-button/button")));

                driver.findElement(Titulo).clear();
                driver.findElement(Titulo).sendKeys("Los pilares de la tierra");
                Report.reportLog(reflectiveClass, "Typed " + "Los pilares de la tierra in Titulo",
                                "INFO",
                                0, Status.PASS, true, "", "", null);

                driver.findElement(NombreAutor).clear();
                driver.findElement(NombreAutor).sendKeys("Ken");
                Report.reportLog(reflectiveClass, "Typed " + "Ken in NombreAutor", "INFO", 0, Status.PASS, true, "",
                                "",
                                null);

                driver.findElement(ApellidosAutor).clear();
                driver.findElement(ApellidosAutor).sendKeys("Follet");
                Report.reportLog(reflectiveClass, "Typed " + "Follet in ApellidosAutor", "INFO", 0, Status.PASS,
                                true, "",
                                "", null);

                new WebDriverWait(driver, Duration.ofSeconds(20))
                                .until(ExpectedConditions.elementToBeClickable(pulsarTodosPrecios));
                Report.reportLog(reflectiveClass, "Condition pulsarTodosPrecios isClickable finished", "ASYNCHRONOUS",
                                0);

                driver.findElement(pulsarTodosPrecios).click();
                Report.reportLog(reflectiveClass, "Clicked pulsarTodosPrecios", "INFO", 0, Status.PASS, true, "", "",
                                null);
                return this;
        }
}