package com.dedalow.pages;

import java.util.logging.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.By;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.aventstack.extentreports.Status;
import com.dedalow.report.Report;
import com.dedalow.utils.Utils;
import com.dedalow.utils.Constant;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class RegistrarsePage {

    private WebDriver driver;
    private Class reflectiveClass;
    private JavascriptExecutor js;
    private static Logger logger = Utils.logger();

    public RegistrarsePage(Class reflectiveClass) throws Exception {
        this.reflectiveClass = reflectiveClass;
        this.driver = (WebDriver) reflectiveClass.getField("driver").get(reflectiveClass);
        PageFactory.initElements(driver, this);
        js = (JavascriptExecutor) driver;

    }

    public RegistrarsePage Registrarse() throws Exception {
        By Registrarse = By.xpath("/html/body/app-root/div/app-registro/deda-grid/div/div[7]/deda-button/button");
        By Usuario2 = By.xpath("/html/body/app-root/div/app-registro/deda-grid/div/div[2]/deda-text-box/input");
        By contr = By.xpath("/html/body/app-root/div/app-registro/deda-grid/div/div[4]/deda-password/div/input");
        By CompPassword = By.xpath("/html/body/app-root/div/app-registro/deda-grid/div/div[6]/deda-password/div/input");

        driver.findElement(Usuario2).clear();
        driver.findElement(Usuario2).sendKeys("PruebAutomatizada");
        Report.reportLog(reflectiveClass, "Typed " + "PruebAutomatizada in Usuario2", "INFO", 0, Status.PASS, true, "",
                "", null);

        driver.findElement(contr).clear();
        driver.findElement(contr).sendKeys("Pautomatizada1234*");
        Report.reportLog(reflectiveClass, "Typed " + "Pautomatizada1234* in contr", "INFO", 0, Status.PASS, true, "",
                "", null);

        driver.findElement(CompPassword).clear();
        driver.findElement(CompPassword).sendKeys("Pautomatizada1234*");
        Report.reportLog(reflectiveClass, "Typed " + "Pautomatizada1234* in CompPassword", "INFO", 0, Status.PASS, true,
                "", "", null);

        new WebDriverWait(driver, Duration.ofSeconds(20)).until(ExpectedConditions.elementToBeClickable(Registrarse));
        Report.reportLog(reflectiveClass, "Condition Registrarse isClickable finished", "ASYNCHRONOUS", 0);

        driver.findElement(Registrarse).click();
        Report.reportLog(reflectiveClass, "Clicked Registrarse", "INFO", 0, Status.PASS, true, "", "", null);
        return this;
    }
}