package com.dedalow.pages;

import java.util.logging.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.By;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.aventstack.extentreports.Status;
import com.dedalow.report.Report;
import com.dedalow.utils.Utils;
import com.dedalow.utils.Constant;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class GuardarResenaPage {

    private WebDriver driver;
    private Class reflectiveClass;
    private JavascriptExecutor js;
    private static Logger logger = Utils.logger();

    public GuardarResenaPage(Class reflectiveClass) throws Exception {
        this.reflectiveClass = reflectiveClass;
        this.driver = (WebDriver) reflectiveClass.getField("driver").get(reflectiveClass);
        PageFactory.initElements(driver, this);
        js = (JavascriptExecutor) driver;

    }

    public GuardarResenaPage GuardarResena() throws Exception {

        By GuardarResena = By
                .xpath("/html/body/app-root/div/app-escribirresena/deda-grid/div/div[4]/deda-button/button");
        By probando = By.xpath("/html/body/app-root/div/app-escribirresena/deda-grid/div/div[2]/deda-text-box/input");

        driver.findElement(probando).clear();
        driver.findElement(probando).sendKeys("PruebaResena");
        Report.reportLog(reflectiveClass, "Typed " + "PruebaResena in probando", "INFO", 0, Status.PASS, true, "", "",
                null);

        new WebDriverWait(driver, Duration.ofSeconds(20)).until(ExpectedConditions.elementToBeClickable(GuardarResena));
        Report.reportLog(reflectiveClass, "Condition GuardarResena isClickable finished", "ASYNCHRONOUS", 0);

        driver.findElement(GuardarResena).click();
        Report.reportLog(reflectiveClass, "Clicked GuardarResena", "INFO", 0, Status.PASS, true, "", "", null);
        return this;
    }
}