package com.dedalow.pages;

import java.util.logging.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.By;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.aventstack.extentreports.Status;
import com.dedalow.report.Report;
import com.dedalow.utils.Utils;
import com.dedalow.utils.Constant;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class TodasResenasPage {

	private WebDriver driver;
	private Class reflectiveClass;
	private JavascriptExecutor js;
	private static Logger logger = Utils.logger();

	public TodasResenasPage(Class reflectiveClass) throws Exception {
		this.reflectiveClass = reflectiveClass;
		this.driver = (WebDriver) reflectiveClass.getField("driver").get(reflectiveClass);
		PageFactory.initElements(driver, this);
		js = (JavascriptExecutor) driver;

	}

	public TodasResenasPage PulsarTodasResenas() throws Exception {

		By PulsarTodasResenas = By.id("btnVerTodasResenas");

		new WebDriverWait(driver, Duration.ofSeconds(20))
				.until(ExpectedConditions.elementToBeClickable(PulsarTodasResenas));
		Report.reportLog(reflectiveClass, "Condition PulsarTodasResenas isClickable finished", "ASYNCHRONOUS", 0);

		driver.findElement(PulsarTodasResenas).click();
		Report.reportLog(reflectiveClass, "Clicked PulsarTodasResenas", "INFO", 0, Status.PASS, true, "", "", null);
		return this;
	}

	public TodasResenasPage PulsarResenas() throws Exception {

		By PulsarResenas = By.xpath(
				"/html/body/app-root/div/app-menuprincipal/deda-grid[1]/div/deda-grid/div/div[3]/deda-button/button");
		By Titulo5 = By.xpath("/html/body/app-root/div/app-menuprincipal/deda-grid[1]/div/div[3]/deda-text-box/input");
		By NombreAutor5 = By
				.xpath("/html/body/app-root/div/app-menuprincipal/deda-grid[1]/div/div[7]/deda-text-box/input");
		By ApellidosAutor5 = By
				.xpath("/html/body/app-root/div/app-menuprincipal/deda-grid[1]/div/div[11]/deda-text-box/input");

		driver.findElement(Titulo5).clear();
		driver.findElement(Titulo5).sendKeys("PruebaResena");
		Report.reportLog(reflectiveClass, "Typed " + "PruebaResena in Titulo5", "INFO", 0, Status.PASS, true, "", "",
				null);

		driver.findElement(NombreAutor5).clear();
		driver.findElement(NombreAutor5).sendKeys("PruebaResena");
		Report.reportLog(reflectiveClass, "Typed " + "PruebaResena in NombreAutor5", "INFO", 0, Status.PASS, true, "",
				"", null);

		driver.findElement(ApellidosAutor5).clear();
		driver.findElement(ApellidosAutor5).sendKeys("PruebaResena");
		Report.reportLog(reflectiveClass, "Typed " + "PruebaResena in ApellidosAutor5", "INFO", 0, Status.PASS, true,
				"", "", null);

		new WebDriverWait(driver, Duration.ofSeconds(20)).until(ExpectedConditions.elementToBeClickable(PulsarResenas));
		Report.reportLog(reflectiveClass, "Condition PulsarResenas isClickable finished", "ASYNCHRONOUS", 0);

		driver.findElement(PulsarResenas).click();
		Report.reportLog(reflectiveClass, "Clicked PulsarResenas", "INFO", 0, Status.PASS, true, "", "", null);
		return this;
	}
}