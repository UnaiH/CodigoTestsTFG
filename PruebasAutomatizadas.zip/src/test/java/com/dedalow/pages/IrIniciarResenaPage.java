package com.dedalow.pages;

import java.util.logging.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.By;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.aventstack.extentreports.Status;
import com.dedalow.report.Report;
import com.dedalow.utils.Utils;
import com.dedalow.utils.Constant;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class IrIniciarResenaPage {

	private WebDriver driver;
	private Class reflectiveClass;
	private JavascriptExecutor js;
	private static Logger logger = Utils.logger();

	public IrIniciarResenaPage(Class reflectiveClass) throws Exception {
		this.reflectiveClass = reflectiveClass;
		this.driver = (WebDriver) reflectiveClass.getField("driver").get(reflectiveClass);
		PageFactory.initElements(driver, this);
		js = (JavascriptExecutor) driver;

	}

	public IrIniciarResenaPage pulsarIniciarSesion() throws Exception {

		By pulsarIniciarSesion = By.id("btnIniciarSesion");

		new WebDriverWait(driver, Duration.ofSeconds(20))
				.until(ExpectedConditions.elementToBeClickable(pulsarIniciarSesion));
		Report.reportLog(reflectiveClass, "Condition pulsarIniciarSesion isClickable finished", "ASYNCHRONOUS", 0);

		driver.findElement(pulsarIniciarSesion).click();
		Report.reportLog(reflectiveClass, "Clicked pulsarIniciarSesion", "INFO", 0, Status.PASS, true, "", "", null);
		return this;
	}

	public IrIniciarResenaPage pulsarIniciarSesion1() throws Exception {

		By pulsarIniciarSesion1 = By.id("btnIniciarSesion");

		new WebDriverWait(driver, Duration.ofSeconds(20))
				.until(ExpectedConditions.elementToBeClickable(pulsarIniciarSesion1));
		Report.reportLog(reflectiveClass, "Condition pulsarIniciarSesion1 isClickable finished", "ASYNCHRONOUS", 0);

		driver.findElement(pulsarIniciarSesion1).click();
		Report.reportLog(reflectiveClass, "Clicked pulsarIniciarSesion1", "INFO", 0, Status.PASS, true, "", "", null);
		return this;
	}

	public IrIniciarResenaPage pulsarIniciarSesion2() throws Exception {

		By pulsarIniciarSesion2 = By.id("btnIniciarSesion");

		new WebDriverWait(driver, Duration.ofSeconds(20))
				.until(ExpectedConditions.elementToBeClickable(pulsarIniciarSesion2));
		Report.reportLog(reflectiveClass, "Condition pulsarIniciarSesion2 isClickable finished", "ASYNCHRONOUS", 0);

		driver.findElement(pulsarIniciarSesion2).click();
		Report.reportLog(reflectiveClass, "Clicked pulsarIniciarSesion2", "INFO", 0, Status.PASS, true, "", "", null);
		return this;
	}

	public IrIniciarResenaPage pulsarIniciarSesion3() throws Exception {

		By pulsarIniciarSesion3 = By.id("btnIniciarSesion");

		new WebDriverWait(driver, Duration.ofSeconds(20))
				.until(ExpectedConditions.elementToBeClickable(pulsarIniciarSesion3));
		Report.reportLog(reflectiveClass, "Condition pulsarIniciarSesion3 isClickable finished", "ASYNCHRONOUS", 0);

		driver.findElement(pulsarIniciarSesion3).click();
		Report.reportLog(reflectiveClass, "Clicked pulsarIniciarSesion3", "INFO", 0, Status.PASS, true, "", "", null);
		return this;
	}

	public IrIniciarResenaPage pulsarIniciarSesion4() throws Exception {

		By pulsarIniciarSesion4 = By.id("btnIniciarSesion");

		new WebDriverWait(driver, Duration.ofSeconds(20))
				.until(ExpectedConditions.elementToBeClickable(pulsarIniciarSesion4));
		Report.reportLog(reflectiveClass, "Condition pulsarIniciarSesion4 isClickable finished", "ASYNCHRONOUS", 0);

		driver.findElement(pulsarIniciarSesion4).click();
		Report.reportLog(reflectiveClass, "Clicked pulsarIniciarSesion4", "INFO", 0, Status.PASS, true, "", "", null);
		return this;
	}

	public IrIniciarResenaPage pulsarIniciarSesion5() throws Exception {

		By pulsarIniciarSesion5 = By.id("btnIniciarSesion");

		new WebDriverWait(driver, Duration.ofSeconds(20))
				.until(ExpectedConditions.elementToBeClickable(pulsarIniciarSesion5));
		Report.reportLog(reflectiveClass, "Condition pulsarIniciarSesion5 isClickable finished", "ASYNCHRONOUS", 0);

		driver.findElement(pulsarIniciarSesion5).click();
		Report.reportLog(reflectiveClass, "Clicked pulsarIniciarSesion5", "INFO", 0, Status.PASS, true, "", "", null);
		return this;
	}
}