package com.dedalow.pages;

import java.util.logging.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.By;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.aventstack.extentreports.Status;
import com.dedalow.report.Report;
import com.dedalow.utils.Utils;
import com.dedalow.utils.Constant;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class EliminarUsuarioPage {

    private WebDriver driver;
    private Class reflectiveClass;
    private JavascriptExecutor js;
    private static Logger logger = Utils.logger();

    public EliminarUsuarioPage(Class reflectiveClass) throws Exception {
        this.reflectiveClass = reflectiveClass;
        this.driver = (WebDriver) reflectiveClass.getField("driver").get(reflectiveClass);
        PageFactory.initElements(driver, this);
        js = (JavascriptExecutor) driver;

    }

    public EliminarUsuarioPage EliminarUsuario() throws Exception {

        By EliminarUsuario = By.id("btnEliminarUsuario");
        By usurario = By.id("usuarioEliminar");

        driver.findElement(usurario).clear();
        driver.findElement(usurario).sendKeys("PruebAutomatizada");
        Report.reportLog(reflectiveClass, "Typed " + "PruebAutomatizada in usurario", "INFO", 0, Status.PASS, true, "",
                "", null);

        new WebDriverWait(driver, Duration.ofSeconds(20))
                .until(ExpectedConditions.elementToBeClickable(EliminarUsuario));
        Report.reportLog(reflectiveClass, "Condition EliminarUsuario isClickable finished", "ASYNCHRONOUS", 0);

        driver.findElement(EliminarUsuario).click();
        Report.reportLog(reflectiveClass, "Clicked EliminarUsuario", "INFO", 0, Status.PASS, true, "", "", null);
        return this;
    }
}