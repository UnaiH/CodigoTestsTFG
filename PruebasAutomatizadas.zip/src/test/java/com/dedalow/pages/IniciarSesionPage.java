package com.dedalow.pages;

import java.util.logging.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.By;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.aventstack.extentreports.Status;
import com.dedalow.report.Report;
import com.dedalow.utils.Utils;
import com.dedalow.utils.Constant;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class IniciarSesionPage {

	private WebDriver driver;
	private Class reflectiveClass;
	private JavascriptExecutor js;
	private static Logger logger = Utils.logger();

	public IniciarSesionPage(Class reflectiveClass) throws Exception {
		this.reflectiveClass = reflectiveClass;
		this.driver = (WebDriver) reflectiveClass.getField("driver").get(reflectiveClass);
		PageFactory.initElements(driver, this);
		js = (JavascriptExecutor) driver;

	}

	public IniciarSesionPage IniciarSesion() throws Exception {

		By IniciarSesion = By.xpath("/html/body/app-root/div/app-iniciosesion/deda-grid/div/div[5]/deda-button/button");
		By Usuario = By.xpath("/html/body/app-root/div/app-iniciosesion/deda-grid/div/div[2]/deda-text-box/input");
		By Password = By.xpath("/html/body/app-root/div/app-iniciosesion/deda-grid/div/div[4]/deda-password/div/input");

		driver.findElement(Usuario).clear();
		driver.findElement(Usuario).sendKeys("administrador");
		Report.reportLog(reflectiveClass, "Typed " + "administrador in Usuario", "INFO", 0, Status.PASS, true, "", "",
				null);

		driver.findElement(Password).clear();
		driver.findElement(Password).sendKeys("administrador");
		Report.reportLog(reflectiveClass, "Typed " + "administrador in Password", "INFO", 0, Status.PASS, true, "", "",
				null);

		new WebDriverWait(driver, Duration.ofSeconds(20)).until(ExpectedConditions.elementToBeClickable(IniciarSesion));
		Report.reportLog(reflectiveClass, "Condition IniciarSesion isClickable finished", "ASYNCHRONOUS", 0);

		driver.findElement(IniciarSesion).click();
		Report.reportLog(reflectiveClass, "Clicked IniciarSesion", "INFO", 0, Status.PASS, true, "", "", null);
		return this;
	}

	public IniciarSesionPage IniciarSesion1() throws Exception {

		By IniciarSesion1 = By
				.xpath("/html/body/app-root/div/app-iniciosesion/deda-grid/div/div[5]/deda-button/button");
		By Usuario1 = By.xpath("/html/body/app-root/div/app-iniciosesion/deda-grid/div/div[2]/deda-text-box/input");
		By Password1 = By
				.xpath("/html/body/app-root/div/app-iniciosesion/deda-grid/div/div[4]/deda-password/div/input");

		driver.findElement(Usuario1).clear();
		driver.findElement(Usuario1).sendKeys("administrador");
		Report.reportLog(reflectiveClass, "Typed " + "administrador in Usuario1", "INFO", 0, Status.PASS, true, "", "",
				null);

		driver.findElement(Password1).clear();
		driver.findElement(Password1).sendKeys("administrador");
		Report.reportLog(reflectiveClass, "Typed " + "administrador in Password1", "INFO", 0, Status.PASS, true, "", "",
				null);

		new WebDriverWait(driver, Duration.ofSeconds(20))
				.until(ExpectedConditions.elementToBeClickable(IniciarSesion1));
		Report.reportLog(reflectiveClass, "Condition IniciarSesion1 isClickable finished", "ASYNCHRONOUS", 0);

		driver.findElement(IniciarSesion1).click();
		Report.reportLog(reflectiveClass, "Clicked IniciarSesion1", "INFO", 0, Status.PASS, true, "", "", null);
		return this;
	}

	public IniciarSesionPage IniciarSesion2() throws Exception {

		By IniciarSesion2 = By.id("btnRegistrarse");

		new WebDriverWait(driver, Duration.ofSeconds(20))
				.until(ExpectedConditions.elementToBeClickable(IniciarSesion2));
		Report.reportLog(reflectiveClass, "Condition IniciarSesion2 isClickable finished", "ASYNCHRONOUS", 0);

		driver.findElement(IniciarSesion2).click();
		Report.reportLog(reflectiveClass, "Clicked IniciarSesion2", "INFO", 0, Status.PASS, true, "", "", null);
		return this;
	}

	public IniciarSesionPage IniciarSesion3() throws Exception {

		By IniciarSesion3 = By
				.xpath("/html/body/app-root/div/app-iniciosesion/deda-grid/div/div[5]/deda-button/button");
		By Usuario3 = By.xpath("/html/body/app-root/div/app-iniciosesion/deda-grid/div/div[2]/deda-text-box/input");
		By Password2 = By
				.xpath("/html/body/app-root/div/app-iniciosesion/deda-grid/div/div[4]/deda-password/div/input");

		driver.findElement(Usuario3).clear();
		driver.findElement(Usuario3).sendKeys("administrador");
		Report.reportLog(reflectiveClass, "Typed " + "administrador in Usuario3", "INFO", 0, Status.PASS, true, "", "",
				null);

		driver.findElement(Password2).clear();
		driver.findElement(Password2).sendKeys("administrador");
		Report.reportLog(reflectiveClass, "Typed " + "administrador in Password2", "INFO", 0, Status.PASS, true, "", "",
				null);

		new WebDriverWait(driver, Duration.ofSeconds(20))
				.until(ExpectedConditions.elementToBeClickable(IniciarSesion3));
		Report.reportLog(reflectiveClass, "Condition IniciarSesion3 isClickable finished", "ASYNCHRONOUS", 0);

		driver.findElement(IniciarSesion3).click();
		Report.reportLog(reflectiveClass, "Clicked IniciarSesion3", "INFO", 0, Status.PASS, true, "", "", null);
		return this;
	}

	public IniciarSesionPage IniciarSesion4() throws Exception {

		By IniciarSesion4 = By
				.xpath("/html/body/app-root/div/app-iniciosesion/deda-grid/div/div[5]/deda-button/button");
		By Usuario4 = By.xpath("/html/body/app-root/div/app-iniciosesion/deda-grid/div/div[2]/deda-text-box/input");
		By Password3 = By
				.xpath("/html/body/app-root/div/app-iniciosesion/deda-grid/div/div[4]/deda-password/div/input");

		driver.findElement(Usuario4).clear();
		driver.findElement(Usuario4).sendKeys("administrador");
		Report.reportLog(reflectiveClass, "Typed " + "administrador in Usuario4", "INFO", 0, Status.PASS, true, "", "",
				null);

		driver.findElement(Password3).clear();
		driver.findElement(Password3).sendKeys("administrador");
		Report.reportLog(reflectiveClass, "Typed " + "administrador in Password3", "INFO", 0, Status.PASS, true, "", "",
				null);

		new WebDriverWait(driver, Duration.ofSeconds(20))
				.until(ExpectedConditions.elementToBeClickable(IniciarSesion4));
		Report.reportLog(reflectiveClass, "Condition IniciarSesion4 isClickable finished", "ASYNCHRONOUS", 0);

		driver.findElement(IniciarSesion4).click();
		Report.reportLog(reflectiveClass, "Clicked IniciarSesion4", "INFO", 0, Status.PASS, true, "", "", null);
		return this;
	}

	public IniciarSesionPage IniciarSesion5() throws Exception {

		By IniciarSesion5 = By
				.xpath("/html/body/app-root/div/app-iniciosesion/deda-grid/div/div[5]/deda-button/button");
		By Usuario5 = By.xpath("/html/body/app-root/div/app-iniciosesion/deda-grid/div/div[2]/deda-text-box/input");
		By Password4 = By
				.xpath("/html/body/app-root/div/app-iniciosesion/deda-grid/div/div[4]/deda-password/div/input");

		driver.findElement(Usuario5).clear();
		driver.findElement(Usuario5).sendKeys("administrador");
		Report.reportLog(reflectiveClass, "Typed " + "administrador in Usuario5", "INFO", 0, Status.PASS, true, "", "",
				null);

		driver.findElement(Password4).clear();
		driver.findElement(Password4).sendKeys("administrador");
		Report.reportLog(reflectiveClass, "Typed " + "administrador in Password4", "INFO", 0, Status.PASS, true, "", "",
				null);

		new WebDriverWait(driver, Duration.ofSeconds(20))
				.until(ExpectedConditions.elementToBeClickable(IniciarSesion5));
		Report.reportLog(reflectiveClass, "Condition IniciarSesion5 isClickable finished", "ASYNCHRONOUS", 0);

		driver.findElement(IniciarSesion5).click();
		Report.reportLog(reflectiveClass, "Clicked IniciarSesion5", "INFO", 0, Status.PASS, true, "", "", null);
		return this;
	}
}