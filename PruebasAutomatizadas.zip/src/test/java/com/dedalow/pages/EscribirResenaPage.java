package com.dedalow.pages;

import java.util.logging.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.By;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.aventstack.extentreports.Status;
import com.dedalow.report.Report;
import com.dedalow.utils.Utils;
import com.dedalow.utils.Constant;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class EscribirResenaPage {

        private WebDriver driver;
        private Class reflectiveClass;
        private JavascriptExecutor js;
        private static Logger logger = Utils.logger();

        public EscribirResenaPage(Class reflectiveClass) throws Exception {
                this.reflectiveClass = reflectiveClass;
                this.driver = (WebDriver) reflectiveClass.getField("driver").get(reflectiveClass);
                PageFactory.initElements(driver, this);
                js = (JavascriptExecutor) driver;

        }

        public EscribirResenaPage PulsarEscribirResena() throws Exception {

                By PulsarEscribirResena = By.xpath(
                                "/html/body/app-root/div/app-menuprincipal/deda-grid[1]/div/deda-grid/div/div[4]/deda-button/button");
                By Titulo1 = By.xpath(
                                "/html/body/app-root/div/app-menuprincipal/deda-grid[1]/div/div[3]/deda-text-box/input");
                By NombreAutor1 = By
                                .xpath("/html/body/app-root/div/app-menuprincipal/deda-grid[1]/div/div[7]/deda-text-box/input");
                By ApellidosAutor1 = By
                                .xpath("/html/body/app-root/div/app-menuprincipal/deda-grid[1]/div/div[11]/deda-text-box/input");

                driver.findElement(Titulo1).clear();
                driver.findElement(Titulo1).sendKeys("PruebaResena");
                Report.reportLog(reflectiveClass, "Typed " + "PruebaResena in Titulo1", "INFO", 0, Status.PASS, true,
                                "", "",
                                null);

                driver.findElement(NombreAutor1).clear();
                driver.findElement(NombreAutor1).sendKeys("PruebaResena");
                Report.reportLog(reflectiveClass, "Typed " + "PruebaResena in NombreAutor1", "INFO", 0, Status.PASS,
                                true, "",
                                "", null);

                driver.findElement(ApellidosAutor1).clear();
                driver.findElement(ApellidosAutor1).sendKeys("PruebaResena");
                Report.reportLog(reflectiveClass, "Typed " + "PruebaResena in ApellidosAutor1", "INFO", 0, Status.PASS,
                                true,
                                "", "", null);

                new WebDriverWait(driver, Duration.ofSeconds(20))
                                .until(ExpectedConditions.elementToBeClickable(PulsarEscribirResena));
                Report.reportLog(reflectiveClass, "Condition PulsarEscribirResena isClickable finished", "ASYNCHRONOUS",
                                0);

                driver.findElement(PulsarEscribirResena).click();
                Report.reportLog(reflectiveClass, "Clicked PulsarEscribirResena", "INFO", 0, Status.PASS, true, "", "",
                                null);
                return this;
        }
}